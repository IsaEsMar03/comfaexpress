export default {
  testEnvironment: "node",
  transform: {}, // Desactiva transformaciones innecesarias
  extensionsToTreatAsEsm: [".js"],
};
